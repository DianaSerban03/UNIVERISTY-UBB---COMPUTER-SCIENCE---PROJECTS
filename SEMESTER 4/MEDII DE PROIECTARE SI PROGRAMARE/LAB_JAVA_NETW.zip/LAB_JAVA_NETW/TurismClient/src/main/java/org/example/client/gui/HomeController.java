package org.example.client.gui;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.example.*;

import java.net.URL;
import java.time.LocalDateTime;
import java.util.*;

public class HomeController implements Initializable, IObserver{
    Angajat connectedAngajat;
    public HomeController(){
        System.err.println("Constructor home controller");
    }
    void setActiveAngajat(Angajat connectedAngajat) throws Exception {
        this.connectedAngajat = connectedAngajat;
        init();
    }
    private IService server;
    public HomeController(IService server){
        this.server = server;
        System.err.println("constructor HomeController cu server param");
    }
    public void setServer(IService s) throws Exception {
        this.server=s;
    }
    void logout() {
        try {
            server.logout(connectedAngajat.getId(), (IObserver) this);
        } catch (Exception e) {
            System.out.println("Logout error " + e);
        }

    }
    ObservableList<Excursie> toate = FXCollections.observableArrayList();
    ObservableList<Excursie> toateFiltrate = FXCollections.observableArrayList();
    ObservableList<Excursie> toateUpdate = FXCollections.observableArrayList();
    void init() throws Exception {
        //populate table
        transp.setCellValueFactory(new PropertyValueFactory<Excursie,Integer>("firmaTransp"));
        pret.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("pret"));
        ora.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("oraPlecare"));
        locuri.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("nrLocuri"));
        //List<Excursie> excursii = (List<Excursie>) server.getAllExcursii();
        //toate.addAll(excursii);
        try {
            for(Excursie participant:server.getAllExcursii())
                toate.add(participant);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        tableExc.setItems(toate);
        //choiceBox
        List<String> optionsList = new ArrayList<>();
        for (Excursie c : server.getAllExcursii())
            optionsList.add(c.getObTuristic());
        ObservableList<String> options = FXCollections.observableArrayList(optionsList);
        numeExc.setItems(options);

    }

    @FXML
    void filterExc(MouseEvent event) throws Exception{
        String nume = numeExc.getValue();
        int ora_1 = Integer.parseInt(ora1.getText());
        int ora_2 = Integer.parseInt(ora2.getText());
        transp.setCellValueFactory(new PropertyValueFactory<Excursie,Integer>("firmaTransp"));
        pret.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("pret"));
        ora.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("oraPlecare"));
        locuri.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("nrLocuri"));
        List<Excursie> excursii = server.findByNameAndTime(nume, ora_1, ora_2);
        try {
            for(Excursie participant:excursii)
                toateFiltrate.add(participant);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        ora1.clear();
        ora2.clear();
        tableExc.setItems(toateFiltrate);

    }

    @FXML
    void addClient(MouseEvent event) throws Exception {
        String nume = TextNume.getText();
        String prenume = TextPrenume.getText();
        Integer telefon = Integer.valueOf(TextTelefon.getText());
        Integer nr_bilete = Integer.valueOf(TextBilete.getText());
        Integer excursie = tableExc.getSelectionModel().getSelectedItem().getIdExc();

        transp.setCellValueFactory(new PropertyValueFactory<Excursie,Integer>("firmaTransp"));
        pret.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("pret"));
        ora.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("oraPlecare"));
        locuri.setCellValueFactory(new PropertyValueFactory<Excursie, Integer>("nrLocuri"));
        Client c = new Client(nume, prenume, telefon, nr_bilete);
        try{
            System.err.println("c ====== " + c.getNume() +" "+ c.getTelefon() +" "+c.getPrenume() + " " + c.getNrBilete());
            System.err.println("excursiaaaaaaa " + excursie);
            Excursie e = new Excursie(excursie.toString(), " ", LocalDateTime.now(), 1.1, nr_bilete);
            server.addClient(e);
//        System.err.println("HOME - inainte toateUpdate-addAll");
//        toateUpdate.addAll(excursii);
//        System.err.println("HOME - dupa toateUpdate-addAll");
        TextNume.clear();
        TextPrenume.clear();
        TextTelefon.clear();
        TextBilete.clear();
            try {
                List<Excursie> updatedExcursii = new ArrayList<>();
                for(Excursie participant:server.getAllExcursii())
                    updatedExcursii.add(participant);
                toate.clear();
                toate.addAll(updatedExcursii);
                tableExc.refresh();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }

//        System.err.println("HOME - inainte tableExc.setItems(toateUpdate);");
//        tableExc.setItems(toateUpdate);
//        System.err.println("HOME - dupa tableExc.setItems(toateUpdate);");
        }
        catch (Exception e) {
            System.err.println("An exception occurred:");
            e.printStackTrace();
            Util.showWarning("Communication error", "Your server probably closed connection");
        }

    }

    @FXML
    void logout(MouseEvent event) {
        Stage stage = (Stage) LOGOUT.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    }

    @Override
    public void notifyAddedClient(Excursie part) throws Exception {
        System.err.println("NotifyAdded " + part);
        Platform.runLater(() -> {
            ObservableList<Excursie> excursies = tableExc.getItems();
            for (Excursie participant : excursies) {
                if (Objects.equals(participant.getId(), part.getId())) {
                    System.err.println("NotifyAdded modificare pentru "+participant);
                    int index = excursies.indexOf(participant);
                    tableExc.getItems().set(index, part);
                    tableExc.getItems().sort(Comparator.comparingInt(Excursie::getNrLocuri).reversed()); // sortam dupa puncte
                    tableExc.refresh();
                    break;
                }
            }
        });
    }


    @FXML
    private Button ADD;

    @FXML
    private TextField TextBilete;

    @FXML
    private TextField TextNume;

    @FXML
    private TextField TextPrenume;

    @FXML
    private TextField TextTelefon;

    @FXML
    private Button UPDATE;

    @FXML
    private Button FILTER;

    @FXML
    private Button LOGOUT;

    @FXML
    private Label label1;

    @FXML
    private Label labelBilete;

    @FXML
    private Label labelDATA;

    @FXML
    private Label labelExcDorita;

    @FXML
    private Label labelNume;

    @FXML
    private Label labelOraDorita;

    @FXML
    private Label labelPrenume;

    @FXML
    private Label labelTelefon;

    @FXML
    private TableColumn<Excursie, Integer> locuri;

    @FXML
    private ChoiceBox<String> numeExc;

    @FXML
    private TableColumn<Excursie, Integer> ora;

    @FXML
    private TextField ora1;

    @FXML
    private TextField ora2;

    @FXML
    private TableColumn<Excursie, Integer> pret;

    @FXML
    private TableColumn<Excursie, Integer> transp;

    @FXML
    private TableView<Excursie> tableExc;

}

