package org.example.client.gui;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import org.example.Angajat;
import org.example.IService;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameText;
    @FXML
    private PasswordField passwordText;


    @FXML
    private Button loginButton;
    private IService server;

    private HomeController mainCtrl;
    //   private Referee crtReferee;
    private Parent mainParent;

    public void setMainParent(Parent mainParent) {
        this.mainParent = mainParent;
    }

    public void setServer(IService server){
        this.server = server;
    }


    @FXML
    void login(ActionEvent event) throws Exception {
        String username = usernameText.getText();
        String password = passwordText.getText();
        System.out.println(username + " " + password + " in controooooller");
      //  Referee referee = new Referee(0,username,password,"a","a","a");
//        System.out.println(crtReferee);
        Angajat a = new Angajat(username,password);
        Platform.runLater(()->{
            try{
                Angajat connectedReferee = server.login(a,  mainCtrl);
                System.out.println("Logged Angajat "+connectedReferee.getUsername());
                Stage stage=new Stage();
                stage.setTitle("Window for "+connectedReferee.getUsername()+")" + connectedReferee.getPassword());
                stage.setScene(new Scene(mainParent));
                stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                    @Override
                    public void handle(WindowEvent event) {
                        mainCtrl.logout();
                        System.exit(0);
                    }
                });
                mainCtrl.setActiveAngajat(connectedReferee);
                mainCtrl.setServer(server);
                stage.show();
                ((Node)(event.getSource())).getScene().getWindow().hide();
//                PRIMESTE DATELE !!!!!
//                for(Participant p: server.getAllParticipants()){
//                    System.out.println(p);
//                }
            }  catch (Exception e) {
                e.printStackTrace();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("MPP Turism");
                alert.setHeaderText("Authentication failure");
                alert.setContentText("Wrong username or password");
                alert.showAndWait();
            }

        });

    }

    private Stage initializeMainStage(Angajat referee) throws Exception {
        mainCtrl.setActiveAngajat(referee);
        Stage stage = new Stage();
        stage.setScene(new Scene(mainParent));
        return stage;
    }

    public void setHomeController(HomeController ctrl) {
        this.mainCtrl = ctrl;
    }

}
