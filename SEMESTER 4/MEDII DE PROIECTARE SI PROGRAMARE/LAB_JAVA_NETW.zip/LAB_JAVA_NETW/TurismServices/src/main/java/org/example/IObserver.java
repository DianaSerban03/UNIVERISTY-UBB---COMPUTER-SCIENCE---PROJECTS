package org.example;


public interface IObserver {
    void notifyAddedClient(Excursie result) throws Exception;
}

