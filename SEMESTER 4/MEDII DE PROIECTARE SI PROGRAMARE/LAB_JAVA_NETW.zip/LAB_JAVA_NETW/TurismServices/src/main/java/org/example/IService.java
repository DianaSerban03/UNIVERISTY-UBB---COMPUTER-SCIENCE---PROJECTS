package org.example;


import java.util.List;

public interface IService {
    Angajat login(Angajat referee, IObserver angajat) throws Exception;

    public void addClient(Excursie e)throws Exception;
    public void logout(String id, IObserver client) throws Exception;

    List<Excursie> findByNameAndTime(String nume, Integer data1, Integer data2) throws Exception;

    Iterable<Angajat> getAllAngajati() throws Exception;

    Iterable<Excursie> getAllExcursii() throws Exception;
}
