package org.example;


import org.example.jdbc.AngajatRepoBD;
import org.example.jdbc.ClientiRepoBD;
import org.example.jdbc.ExcursieRepoBD;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ServiceImpl implements IService {
    private AngajatRepoBD angRepo;
    private ClientiRepoBD cliRepo;
    private ExcursieRepoBD excRepo;
    private Map<String,IObserver> loggedAngajati;

    public ServiceImpl(AngajatRepoBD A, ClientiRepoBD C, ExcursieRepoBD E){
        angRepo = A;
        cliRepo = C;
        excRepo = E;
        loggedAngajati = new ConcurrentHashMap<>();
    }


    @Override
    public synchronized Angajat login(Angajat a, IObserver client) throws Exception {
        System.out.println("Angajat PRIMIT: " + a);
        Angajat a1 = angRepo.findOne(a.getUsername());
        System.out.println("Ang GASIT: "+a1.getUsername()+ " " + a1.getPassword());
//        if(referee1!=null){
//            if(loggedClients.get(referee.getId())!=null)
//                throw new Exception("Referee already logged in!");
//            loggedClients.put(referee.getId(),client);
//        }
//        else
//            throw new Exception("Authetification failed!");
        loggedAngajati.put(a1.getUsername(),client);
        return a1;
    }



    private final int defaultThreadsNo=4;

    public synchronized void notifyAddedClient(Excursie c){
        ExecutorService executorService= Executors.newFixedThreadPool(this.defaultThreadsNo);
        loggedAngajati.forEach((id,client)->{
            IObserver obs=loggedAngajati.get(id);
            executorService.execute(()->{
                try{
                    System.out.println("Notifying ["+id+"]");
                    obs.notifyAddedClient(c);
                }catch (Exception e){
                    System.out.println("Error notifying referee with ID: " + id + " Message: " + e.getMessage());
                }
            });
        });
        executorService.shutdown();
    }


    @Override
    public void addClient(Excursie e){
        System.err.println("AM AJUNS in ServiceImpl addClient");
//        List<Excursie> excursieList = new ArrayList<>();
//        for (Excursie e : excRepo.findAll()) {
//            Integer scade_locuri = e.getNrLocuri()-c.getNrBilete();
//            if (Objects.equals(e.getId(), idExc))
//            { Excursie newE = new Excursie(e.getObTuristic(), e.getFirmaTransp(), e.getOraPlecare(), e.getPret(), scade_locuri);
//                excursieList.add(newE);
//                cliRepo.save(new Client(c.getNume(), c.getPrenume(), c.getTelefon(), scade_locuri));
//               // notifyAddedClient(newE);
//            break;}
//            else excursieList.add(e);
//
//        }
        //e = vine cu idul,.. de la excursia ce trebuie modificata si cate locuri trebuie
        System.err.println("idul e " + Integer.valueOf(e.getObTuristic()));

        Excursie oldExc = excRepo.findOne(Integer.valueOf(e.getObTuristic()));
        Integer scade_locuri = oldExc.getNrLocuri()-e.getNrLocuri();
        oldExc.setIdExc(Integer.valueOf(e.getObTuristic()));
        System.err.println("oldExc " + oldExc.getIdExc() + " obTuristic " + oldExc.getObTuristic()+" nr locuri "+oldExc.getNrLocuri());

        Excursie newE = new Excursie(oldExc.getObTuristic(), oldExc.getFirmaTransp(), oldExc.getOraPlecare(), oldExc.getPret(), scade_locuri);
        newE.setIdExc(Integer.valueOf(e.getObTuristic()));
        System.err.println("newExc " + newE.getIdExc() + " obTuristic " + newE.getObTuristic()+" nr locuri "+newE.getNrLocuri());

        excRepo.update(newE);
        System.err.println("afterUpdate " + newE.getIdExc() + " obTuristic " + newE.getObTuristic()+" nr locuri "+newE.getNrLocuri());
        //cliRepo.save(new Client(c.getNume(), c.getPrenume(), c.getTelefon(), c.getNrBilete()));
        notifyAddedClient(newE);
    }

    @Override
    public void logout(String id, IObserver client) throws Exception {
        IObserver localClient=loggedAngajati.remove(id);
        if (localClient==null)
            throw new Exception("Angajat "+id+" is not logged in.");
    }

    @Override
    public List<Excursie> findByNameAndTime(String nume, Integer data1, Integer data2) {
        List<Excursie> excursieList = new ArrayList<>();
        for (Excursie e : excRepo.findAll()) {
            System.out.println("excursriile suuuuuuuuuunt" + " "+ e.getObTuristic() + " "+nume);
            System.out.println(e.getOraPlecare().getHour() +" si data1 selectat= " + data1);
            if (Objects.equals(e.getObTuristic(), nume) && e.getOraPlecare().getHour()>data1)
                excursieList.add(e);
        }
        return excursieList;
    }

    @Override
    public Iterable<Angajat> getAllAngajati() {return angRepo.findAll();}

    public Iterable<Client> getAllClienti() {return cliRepo.findAll();}

    @Override
    public Iterable<Excursie> getAllExcursii() {return excRepo.findAll();}
}
