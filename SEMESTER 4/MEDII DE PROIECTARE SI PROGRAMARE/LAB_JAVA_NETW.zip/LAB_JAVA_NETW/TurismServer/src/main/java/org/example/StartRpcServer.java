package org.example;


import org.example.jdbc.AngajatRepoBD;
import org.example.jdbc.ClientiRepoBD;
import org.example.jdbc.ExcursieRepoBD;
import org.example.utils.AbstractServer;
import org.example.utils.ServerException;
import org.example.utils.TurismRpcConcurrentServer;

import java.io.IOException;
import java.util.Properties;

public class StartRpcServer {
    private static int defaultPort=55554;
    public static void main(String[] args) {
        Properties serverProps=new Properties();
        try {
            serverProps.load(StartRpcServer.class.getResourceAsStream("/server.properties"));
            System.out.println("Server properties set. ");
            serverProps.list(System.out);
        } catch (IOException e) {
            System.err.println("Cannot find server.properties "+e);
            return;
        }
        AngajatRepoBD angajatRepoBD=new AngajatRepoBD(serverProps);
        ClientiRepoBD clientiRepoBD = new ClientiRepoBD(serverProps);
        ExcursieRepoBD excursieRepoBD = new ExcursieRepoBD(serverProps);
        IService sv = new ServiceImpl(angajatRepoBD,clientiRepoBD,excursieRepoBD);

        for(Angajat ref: angajatRepoBD.findAll()){
            System.out.println("usernem: " + ref.getUsername() + " password: " + ref.getPassword());
        }
        System.err.println("CLIENTI");
        //Integer i=0;
        for(Excursie ref: excursieRepoBD.findAll()){
            //ref.setId(i);
            System.out.println("id "+ ref.getIdExc() + " ob turistic: " + ref.getObTuristic() + " nr_locuri: " + ref.getNrLocuri());
            //i++;
        }

        int trServerPort=defaultPort;
        try {
            trServerPort = Integer.parseInt(serverProps.getProperty("server.port"));
        }catch (NumberFormatException nef){
            System.err.println("Wrong  Port Number"+nef.getMessage());
            System.err.println("Using default port "+defaultPort);
        }
        System.out.println("Starting server on port: "+trServerPort);
        AbstractServer server = new TurismRpcConcurrentServer(trServerPort, sv);
        try {
            server.start();
        } catch (ServerException e) {
            System.err.println("111111 Error starting the server" + e.getMessage());
        }finally {
            try {
                server.stop();
            }catch(ServerException e){
                System.err.println("Error stopping server "+e.getMessage());
            }
        }
    }
}

