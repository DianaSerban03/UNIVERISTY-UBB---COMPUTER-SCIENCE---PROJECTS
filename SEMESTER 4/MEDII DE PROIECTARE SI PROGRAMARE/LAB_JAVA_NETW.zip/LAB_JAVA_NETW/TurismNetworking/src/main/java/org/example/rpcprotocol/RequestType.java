package org.example.rpcprotocol;

public enum RequestType {
    LOGIN,
    LOGOUT,
    ADDCLIENT,
    GET_ANGAJATI,
    GET_EXCURSII,
    FINDBYNAMETIME
}
