package org.example.rpcprotocol;

public enum ResponseType {
    OK,
    ERROR,
    NEW_CLIENT,
    GET_ANGAJATI,
    GET_EXCURSII,
    FINDBYNAMETIME
}
