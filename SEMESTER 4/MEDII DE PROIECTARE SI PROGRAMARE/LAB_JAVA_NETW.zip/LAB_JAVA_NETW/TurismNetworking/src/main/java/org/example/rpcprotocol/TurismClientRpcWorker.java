package org.example.rpcprotocol;

import org.example.*;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

import static org.example.rpcprotocol.ResponseType.*;


public class TurismClientRpcWorker implements  Runnable, IObserver {
    private IService server;
    private Socket connection;
    private ObjectInputStream input;
    private ObjectOutputStream output;
    private volatile boolean connected;

    public TurismClientRpcWorker(IService server, Socket connection){
        this.server = server;
        this.connection = connection;
        try{
            output=new ObjectOutputStream(connection.getOutputStream());
            output.flush();
            input=new ObjectInputStream(connection.getInputStream());
            connected=true;
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while(connected){
            try {
                Object request=input.readObject();
                Response response=handleRequest((Request)request);
                if (response!=null){
                    sendResponse(response);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        try {
            input.close();
            output.close();
            connection.close();
        } catch (IOException e) {
            System.out.println("Error "+e);
        }
    }

    private Response handleRequest(Request request) {
        Response response = null;
        if (request.type()== RequestType.LOGIN){
            System.out.println("Login request ..."+request.type());
            Angajat angajat = (Angajat) request.data();
            System.out.println(angajat);
            try {
                Angajat foundRefere = server.login(angajat, this);
                //return okResponse;
                return new Response.Builder().type(OK).data(foundRefere).build();
            } catch (Exception e) {
                connected=false;
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }
        if (request.type()== RequestType.LOGOUT){
            System.out.println("Logout request");
            String angajat = (String) request.data();
            try {
                server.logout(angajat, this);
                connected=false;
                return okResponse;

            } catch (Exception e) {
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }
//        if (request.type()== RequestType.ADDCLIENT){
//            System.out.println("AddedClientRequest ...");
//            Client c = (Client)request.data();
//            Integer idExc = (Integer) request.data();
//            try {
//                server.addClient(idExc, c);
//                return okResponse;
//            } catch (Exception e) {
//                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
//            }
//        }
        if (request.type() == RequestType.ADDCLIENT) {
            System.out.println("AddedClientRequest ...");
            Excursie c = (Excursie) request.data();
            try {
                server.addClient(c);
                return okResponse;
            } catch (Exception e) {
                return new Response.Builder()
                        .type(ResponseType.ERROR)
                        .data(e.getMessage())
                        .build();
            }
        }
        if (request.type()== RequestType.FINDBYNAMETIME){
            System.out.println("FINDBYNAMETIME...");
            Excursie ref=(Excursie) request.data();
            try{
                int oraDinLocalDateTime = ref.getOraPlecare().getHour();
                List<Excursie> participants = server.findByNameAndTime(ref.getObTuristic(), oraDinLocalDateTime, 12);
                return new Response.Builder().type(FINDBYNAMETIME).data(participants).build();
            }catch(Exception e){
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }
        if (request.type()== RequestType.GET_ANGAJATI){
            System.out.println("Get angajati...");
            int ref=(int)request.data();
            try{
                Iterable<Angajat> topParticipants = server.getAllAngajati();
                return new Response.Builder().type(GET_ANGAJATI).data(topParticipants).build();
            }catch(Exception e){
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }
        if (request.type()== RequestType.GET_EXCURSII){
            System.out.println("Get excursii...");
            int ref=(int)request.data();
            try{
                Iterable<Excursie> excursii = server.getAllExcursii();
                return new Response.Builder().type(GET_EXCURSII).data(excursii).build();
            }catch(Exception e){
                return new Response.Builder().type(ResponseType.ERROR).data(e.getMessage()).build();
            }
        }

        return response;
    }

    private static Response okResponse=new Response.Builder().type(OK).build();
    private static Response errorResponse=new Response.Builder().type(ResponseType.ERROR).build();


    private void sendResponse(Response resp) throws IOException{
        System.out.println("Adding client"+resp);
        output.writeObject(resp);
        output.flush();
    }


    @Override
    public void notifyAddedClient(Excursie c) throws Exception {
        Response resp = new Response.Builder().type(ResponseType.NEW_CLIENT).data(c).build();
        System.out.println("Client added" + c);
        try{
            sendResponse(resp);
        }catch(IOException e){
            throw new Exception("Adding client error");
        }
    }
}
