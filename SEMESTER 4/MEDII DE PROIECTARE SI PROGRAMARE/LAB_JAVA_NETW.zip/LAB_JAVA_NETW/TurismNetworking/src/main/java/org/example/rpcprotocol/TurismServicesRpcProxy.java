package org.example.rpcprotocol;

import org.example.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class TurismServicesRpcProxy implements IService {
    private String host;
    private int port;
    private IObserver client;
    private ObjectInputStream input;
    private ObjectOutputStream output;
    private Socket connection;
    private BlockingQueue<Response> qresponses;
    private volatile boolean finished;

    public TurismServicesRpcProxy(String host, int port){
        this.host = host;
        this.port = port;
        qresponses = new LinkedBlockingDeque<Response>();
    }

    @Override
    public Angajat login(Angajat referee, IObserver client) throws Exception {
        initializeConnection();
        Request req=new Request.Builder().type(RequestType.LOGIN).data(referee).build();
        sendRequest(req);
        Response response=readResponse();
        if(response.type()==ResponseType.OK){
            this.client=client;
            Angajat r = (Angajat) response.data();
            return r;
        }
        if(response.type()==ResponseType.ERROR){
            String err = response.data().toString();
            closeConnection();
            throw new Exception(err);
        }
        return null;
    }

//    @Override
//    public List<Excursie> addClient(Integer idExc, Client result) throws Exception {
//        System.err.println("AM AJUNS in ServRpcProxy addClient");
//        Request req=new Request.Builder().type(RequestType.ADDCLIENT).data(result).idExc(idExc).build();
//        System.err.println("Before sending addClient");
//        sendRequest(req);
//        System.err.println("After sending addClient");
//        Response response = readResponse();
//        System.err.println("Received addClient" +response);
//        if(response.type()==ResponseType.ERROR){
//            String err=response.data().toString();
//            throw new Exception(err);
//        }
//        return null;
//    }
@Override
public void addClient(Excursie e) throws Exception {
    System.err.println("AM AJUNS in ServRpcProxy addClient");
    Request req = new Request.Builder()
            .type(RequestType.ADDCLIENT)
            .data(e)
            .build();
    System.err.println("Before sending addClient");
    sendRequest(req);
    System.err.println("After sending addClient");
    Response response = readResponse();
    System.err.println("Received addClient" +response);
    if (response.type() == ResponseType.ERROR) {
        System.err.println("EROARE IN ADDCLIENT RPC PROXY");
        String err = response.data().toString();
        throw new Exception(err);
    }
}



    @Override
    public void logout(String id, IObserver client) throws Exception {
        Request req = new Request.Builder().type(RequestType.LOGOUT).data(id).build();
        sendRequest(req);
        Response response=readResponse();
        closeConnection();
        if(response.type()==ResponseType.ERROR){
            String err=response.data().toString();
            throw new Exception(err);
        }
    }

//    @Override
//    public List<Excursie> findByNameAndTime(String nume, Integer data1, Integer data2)throws Exception{
//        Request req=new Request.Builder().type(RequestType.FINDBYNAMETIME).data(nume).build();
//        sendRequest(req);
//        Response response = readResponse();
//        if(response.type()==ResponseType.ERROR){
//            String err=response.data().toString();
//            throw new Exception(err);
//        }
//        return null;
//    }
    @Override
    public List<Excursie> findByNameAndTime(String nume, Integer data1, Integer data2) throws Exception {

        LocalDateTime dateTime = LocalDateTime.of(2022, 4, 20, data1, 0);

        Excursie excursie = new Excursie(nume, "", dateTime, 1.0,0);
        Request req = new Request.Builder().type(RequestType.FINDBYNAMETIME).data(excursie).build();
        sendRequest(req);
        Response response = readResponse();if (response.type() == ResponseType.ERROR) {
        String err = response.data().toString();
          throw new Exception(err);
        }
        List<Excursie> participants = (List<Excursie>) response.data();
        return participants;
    }
    @Override
    public Iterable<Angajat> getAllAngajati() throws Exception{
        Request req = new Request.Builder().type(RequestType.GET_ANGAJATI).data(1).build();
        sendRequest(req);
        Response response = readResponse();
        if(response.type()==ResponseType.ERROR){
            String err=response.data().toString();
            throw new Exception(err);
        }
        Iterable<Angajat> participants=(Iterable<Angajat>) response.data();
        return participants;
    }
    @Override
    public Iterable<Excursie> getAllExcursii() throws Exception{
        Request req = new Request.Builder().type(RequestType.GET_EXCURSII).data(1).build();
        sendRequest(req);
        Response response = readResponse();
        if(response.type()==ResponseType.ERROR){
            String err=response.data().toString();
            throw new Exception(err);
        }
        Iterable<Excursie> participants=(Iterable<Excursie>) response.data();
        return participants;
    }
    private void initializeConnection() throws Exception {
        try {
            connection=new Socket(host,port);
            output=new ObjectOutputStream(connection.getOutputStream());
            output.flush();
            input=new ObjectInputStream(connection.getInputStream());
            finished=false;
            startReader();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void closeConnection() {
        finished=true;
        try {
            input.close();
            output.close();
            connection.close();
            client=null;
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    private Response readResponse() throws Exception {
        Response response=null;
        try{

            response=qresponses.take();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return response;
    }

    private void sendRequest(Request request)throws Exception {
        try {
            output.writeObject(request);
            output.flush();
        } catch (IOException e) {
            throw new Exception("Error sending object "+e);
        }

    }

    private void startReader(){
        Thread tw=new Thread(new ReaderThread());
        tw.start();
    }

    private void handleUpdate(Response response){
        if (response.type()== ResponseType.NEW_CLIENT){
            Excursie result = (Excursie) response.data();
            try {
                client.notifyAddedClient(result);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isUpdate(Response response){
        return response.type()== ResponseType.NEW_CLIENT;
    }

    private class ReaderThread implements Runnable{
        public void run() {
            while(!finished){
                try {
                    Object response=input.readObject();
                    System.out.println("response received "+response);
                    if (isUpdate((Response)response)){
                        handleUpdate((Response)response);
                    }else{

                        try {
                            qresponses.put((Response)response);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                } catch (IOException e) {
                    System.out.println("Reading error "+e);
                } catch (ClassNotFoundException e) {
                    System.out.println("Reading error "+e);
                }
            }
        }
    }
}
