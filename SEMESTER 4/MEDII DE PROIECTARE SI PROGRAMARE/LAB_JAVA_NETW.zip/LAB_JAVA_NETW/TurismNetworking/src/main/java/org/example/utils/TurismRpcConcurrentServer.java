package org.example.utils;



import org.example.IService;
import org.example.rpcprotocol.TurismClientRpcWorker;

import java.net.Socket;

public class TurismRpcConcurrentServer extends AbsConcurrentServer{
    private IService turismServer;

    public TurismRpcConcurrentServer(int port,IService turismServer) {
        super(port);
        this.turismServer = turismServer;
        System.out.println("Turism - TurismRpcConcurrentServer");
    }

    @Override
    protected Thread createWorker(Socket client) {
        TurismClientRpcWorker worker = new TurismClientRpcWorker(turismServer,client);
        Thread tw=new Thread(worker);
        return tw;
    }

    @Override
    public void stop(){
        System.out.println("Stopping services din RpcConcurrent...");
    }
}
