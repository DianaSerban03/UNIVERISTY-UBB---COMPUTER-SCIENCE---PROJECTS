package org.example.jdbc;

import org.example.jdbc.exception.MyException;

public class RepositoryException extends MyException
{
    public RepositoryException(String message) { super(message); }

}
