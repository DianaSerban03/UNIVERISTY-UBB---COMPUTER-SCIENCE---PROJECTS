package org.example;


public interface IClienti extends Repository<Integer, Client>{
}
