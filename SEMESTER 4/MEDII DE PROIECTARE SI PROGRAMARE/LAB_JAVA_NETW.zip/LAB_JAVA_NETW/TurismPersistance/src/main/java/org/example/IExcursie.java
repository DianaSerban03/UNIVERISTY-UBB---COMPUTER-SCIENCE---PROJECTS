package org.example;


public interface IExcursie extends Repository<Integer, Excursie>{

}
