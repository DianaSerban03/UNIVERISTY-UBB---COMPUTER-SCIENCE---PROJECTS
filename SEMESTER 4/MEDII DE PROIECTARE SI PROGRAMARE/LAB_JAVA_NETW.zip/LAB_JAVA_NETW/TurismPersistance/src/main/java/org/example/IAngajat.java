package org.example;



public interface IAngajat extends Repository<String, Angajat> {

}
