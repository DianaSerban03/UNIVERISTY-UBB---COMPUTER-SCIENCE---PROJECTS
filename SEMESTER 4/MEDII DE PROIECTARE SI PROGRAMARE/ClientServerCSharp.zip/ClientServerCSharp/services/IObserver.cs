﻿
using model;

namespace services
{
    public interface IObserver
    {
        void notifyAddedClient(Excursie e);
    }
}