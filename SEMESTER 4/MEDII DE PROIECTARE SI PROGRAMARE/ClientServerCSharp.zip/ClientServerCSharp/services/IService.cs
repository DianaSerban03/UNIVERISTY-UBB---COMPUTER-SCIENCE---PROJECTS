﻿
using model;
using services;
using System;
using System.Collections.Generic;

public interface IService
{
    Angajat Login(Angajat a, IObserver client);

    void AddClient(Excursie e);
    void Logout(string id, IObserver client);

    List<Excursie> FindByNameAndTime(string nume, int data1, int data2);

    List<Angajat> GetAllAngajati();

    List<Excursie> GetAllExcursii();
}