﻿using System.Configuration;
using System.Data;
using log4net;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using persistence;
using model;

namespace persistence
{
    public class AngajatRepoBD : IAngajat
    {
        private static readonly ILog logger = LogManager.GetLogger("AngajatRepoBD");
       // IDictionary<String, string> props;
        public AngajatRepoBD()
        {
            logger.Info("Creating IAngajat Repo ");
        }

        public IEnumerable<Angajat> FindAll()
        {
            IDbConnection conn = persistence.DBUtils.getConnection();
            IList<Angajat> angajati = new List<Angajat>();

            using (var command = conn.CreateCommand())
            {
                command.CommandText = "SELECT * FROM angajati";
                {
                    using (var dataR = command.ExecuteReader())
                    {
                        while (dataR.Read())
                        {
                            String username = dataR.GetString(0);
                            String password = dataR.GetString(1);
                            Angajat angajat = new Angajat(username, password);
                            angajati.Add(angajat);
                        }
                    }
                }
            }

            return angajati;
        }

        public Angajat FindOne(string username)
        {
            logger.InfoFormat("Entering findOne with value {0}", username);
            IDbConnection conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText = "SELECT * FROM angajati WHERE username = @Username";
                IDbDataParameter paramId = command.CreateParameter();
                paramId.ParameterName = "@Username";
                paramId.Value = username;
                command.Parameters.Add(paramId);
                using (var dataR = command.ExecuteReader())
                {
                    if (dataR.Read())
                    {
                        String password = dataR.GetString(1);
                        Angajat angajat = new Angajat(username, password);
                        logger.InfoFormat("Existing findOne with value {0}", angajat);
                        return angajat;
                    }
                }
            }
            logger.InfoFormat("Existing findOne with value {0}", null);
            return null;

        }

        public void Save(Angajat angajat)
        {
            logger.InfoFormat("Save angajat");
            IDbConnection conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText = "INSERT INTO angajati (username, password) VALUES (@Username, @Password)";
                var paramId = command.CreateParameter();
                paramId.ParameterName = "@Username";
                paramId.Value = angajat.Username;
                command.Parameters.Add(paramId);

                var paramId1 = command.CreateParameter();
                paramId1.ParameterName = "@Password";
                paramId1.Value = angajat.Password;
                command.Parameters.Add(paramId1);

                var dataR = command.ExecuteNonQuery();

            }
        }

        public void Delete(string username)
        {
            IDbConnection conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText = "DELETE FROM angajati WHERE username = @Username";
                IDbDataParameter paramId = command.CreateParameter();
                paramId.ParameterName = "@username";
                paramId.Value = username;
                command.Parameters.Add(paramId);
                var dataR = command.ExecuteNonQuery();

            }
        }

        public void Update(Angajat entity)
        {
            Angajat account = FindOne(entity.Username);
            IDbConnection conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText = "update angajati set password = @password where username = @username";
                IDbDataParameter paramId = command.CreateParameter();
                paramId.ParameterName = "@username";
                paramId.Value = account.Username;
                command.Parameters.Add(paramId);

                paramId.ParameterName = "@password";
                paramId.Value = entity.Password;
                command.Parameters.Add(paramId);
            }
        }

    }
}