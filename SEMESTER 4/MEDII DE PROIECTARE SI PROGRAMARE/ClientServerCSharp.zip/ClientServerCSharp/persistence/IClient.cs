﻿

using model;

namespace persistence
{
    public interface IClient : IRepository<int, Client>
    {

    }
}