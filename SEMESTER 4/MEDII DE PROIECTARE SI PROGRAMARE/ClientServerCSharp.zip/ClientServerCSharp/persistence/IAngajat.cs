﻿
using model;

namespace persistence

{
    public interface IAngajat : IRepository<string, Angajat>
    {

    }
}