﻿

using System;

namespace persistence
{
    public class RepositoryException : Exception
    {
        public RepositoryException(string message) : base(message) { }
    }
}