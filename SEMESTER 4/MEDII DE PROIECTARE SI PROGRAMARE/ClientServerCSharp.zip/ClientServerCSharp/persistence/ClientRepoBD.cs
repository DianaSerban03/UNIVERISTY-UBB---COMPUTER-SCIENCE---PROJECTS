﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using log4net;
using model;
using persistence;

namespace persistence
{
    public class ClientRepoBD : IClient
    {

        private static readonly ILog logger = LogManager.GetLogger("ClientRepoBD");
       // IDictionary<String, string> props;

        public ClientRepoBD()
        {
            logger.Info("Creating IClient Repo ");
        }

        public IEnumerable<Client> FindAll()
        {
            IDbConnection conn = DBUtils.getConnection();
            IList<Client> clienti = new List<Client>();

            using (var command = conn.CreateCommand())
            {
                command.CommandText = "SELECT * FROM clienti";
                {
                    using (var dataR = command.ExecuteReader())
                    {
                        while (dataR.Read())
                        {
                            String nume = dataR.GetString(0);
                            String prenume = dataR.GetString(1);
                            int nrBilete = dataR.GetInt32(2);
                            int telefon = dataR.GetInt32(3);
                            int id = dataR.GetInt32(4);
                            Client client = new Client(nume, prenume, telefon, nrBilete);
                            client.Id = id;
                            clienti.Add(client);
                        }
                    }
                }
            }

            return clienti;
        }

        public Client FindOne(int id)
        {
            logger.InfoFormat("Entering findOne with value {0}", id);
            IDbConnection conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText = "SELECT * FROM clienti WHERE id_client = @id";
                IDbDataParameter paramId = command.CreateParameter();
                paramId.ParameterName = "@id";
                paramId.Value = id;
                command.Parameters.Add(paramId);
                using (var dataR = command.ExecuteReader())
                {
                    if (dataR.Read())
                    {
                        String nume = dataR.GetString(1);
                        String prenume = dataR.GetString(2);
                        int nrBilete = dataR.GetInt32(3);
                        int telefon = dataR.GetInt32(4);
                        Client client = new Client(nume, prenume, nrBilete, telefon);
                        logger.InfoFormat("Existing findOne with value {0}", client);
                        return client;
                    }
                }
            }

            logger.InfoFormat("Existing findOne with value {0}", null);
            return null;

        }

        public void Save(Client client)
        {
            var conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText =
                    "INSERT INTO clienti (nume, prenume, nr_bilete, telefon) VALUES (@nume, @prenume, @nr_bilete, @telefon)";
                var paramId = command.CreateParameter();
                paramId.ParameterName = "@nume";
                paramId.Value = client.Nume;
                command.Parameters.Add(paramId);

                var paramId2 = command.CreateParameter();
                paramId2.ParameterName = "@prenume";
                paramId2.Value = client.Prenume;
                command.Parameters.Add(paramId2);

                var paramId3 = command.CreateParameter();
                paramId3.ParameterName = "@nr_bilete";
                paramId3.Value = client.NrBilete;
                command.Parameters.Add(paramId3);

                var paramId4 = command.CreateParameter();
                paramId4.ParameterName = "@telefon";
                paramId4.Value = client.Telefon;
                command.Parameters.Add(paramId4);

                var dataR = command.ExecuteNonQuery();
            }
        }

        public void Delete(int id)
        {
            IDbConnection conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText = "DELETE FROM clienti WHERE id_client = @id";
                IDbDataParameter paramId = command.CreateParameter();
                paramId.ParameterName = "@id";
                paramId.Value = id;
                command.Parameters.Add(paramId);
                var dataR = command.ExecuteNonQuery();

            }
        }

        public void Update(Client entity)
        {
            /*
                    Client account = this.FindOne(entity.Id);
                    IDbConnection conn = DBUtils.getConnection(props);
                    using (var command = conn.CreateCommand())
                   {
                       command.CommandText = "update Client set nume = @nume, prenume=@prenume, nr_bilete=@nr_bilete, telefon=@telefon where id_client = @id";
                       IDbDataParameter paramId = command.CreateParameter();
                       paramId.ParameterName = "@id";
                       paramId.Value = entity.Id;
                       command.Parameters.Add(paramId);

                       paramId.ParameterName = "@password";
                       paramId.Value = entity.Password;
                       command.Parameters.Add(paramId);
                   }
                }*/

        }
    }
}