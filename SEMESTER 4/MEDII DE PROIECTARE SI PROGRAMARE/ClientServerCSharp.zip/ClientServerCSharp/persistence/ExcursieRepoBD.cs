﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using log4net;
using model;
using persistence;

namespace persistence
{
    public class ExcursieRepoBD : IExcursie
    {
        private static readonly ILog logger = LogManager.GetLogger("ExcursieRepoBD");
        //IDictionary<String, string> props;

        public ExcursieRepoBD()
        {
            logger.Info("Creating IExcursie Repo ");
        }

        public IEnumerable<Excursie> FindAll()
        {
            IDbConnection conn = DBUtils.getConnection();
            IList<Excursie> excursii = new List<Excursie>();

            using (var command = conn.CreateCommand())
            {
                command.CommandText = "SELECT * FROM excursii";
                {
                    using (var dataR = command.ExecuteReader())
                    {
                        while (dataR.Read())
                        {
                            String ob_turistic = dataR.GetString(0);
                            String firma_transport = dataR.GetString(1);
                            DateTime ora_plecare = dataR.GetDateTime(2);
                            int pret = dataR.GetInt32(3);
                            int nr_locuri = dataR.GetInt32(4);
                            int id = dataR.GetInt32(5);
                            Excursie excursie = new Excursie(ob_turistic, firma_transport, ora_plecare, pret, nr_locuri);
                            excursie.Id = id;
                            excursii.Add(excursie);
                        }
                    }
                }
            }

            return excursii;
        }

        public Excursie FindOne(int id)
        {
            logger.InfoFormat("Entering findOne with value {0}", id);
            IDbConnection conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText = "SELECT * FROM excursii WHERE id_excursie = @id";
                IDbDataParameter paramId = command.CreateParameter();
                paramId.ParameterName = "@id";
                paramId.Value = id;
                command.Parameters.Add(paramId);
                using (var dataR = command.ExecuteReader())
                {
                    if (dataR.Read())
                    {
                        String ob_turistic = dataR.GetString(0);
                        String firma_transport = dataR.GetString(1);
                        DateTime ora_plecare = dataR.GetDateTime(2);
                        int pret = dataR.GetInt32(3);
                        int nr_locuri = dataR.GetInt32(4);
                        Excursie excursie = new Excursie(ob_turistic, firma_transport, ora_plecare, pret, nr_locuri);
                        logger.InfoFormat("Existing findOne with value {0}", excursie);
                        return excursie;
                    }
                }
            }

            logger.InfoFormat("Existing findOne with value {0}", null);
            return null;

        }

        public void Save(Excursie excursie)
        {
            var conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText =
                    "insert into excursii (ob_turistic, firma_transport, ora_plecare, pret, nr_locuri) values (@ob_turistic,@firma, @ora, @pret, @nr_locuri)";
                var paramId = command.CreateParameter();
                paramId.ParameterName = "@ob_turistic";
                paramId.Value = excursie.ObTuristic;
                command.Parameters.Add(paramId);

                var paramId1 = command.CreateParameter();
                paramId1.ParameterName = "@firma";
                paramId1.Value = excursie.FirmaTransp;
                command.Parameters.Add(paramId1);

                var paramId2 = command.CreateParameter();
                paramId2.ParameterName = "@ora";
                paramId2.Value = excursie.OraPlecare;
                command.Parameters.Add(paramId2);

                var paramId3 = command.CreateParameter();
                paramId3.ParameterName = "@pret";
                paramId3.Value = excursie.Pret;
                command.Parameters.Add(paramId3);

                var paramId4 = command.CreateParameter();
                paramId4.ParameterName = "@nr_locuri";
                paramId4.Value = excursie.NrLocuri;
                command.Parameters.Add(paramId4);

                var dataR = command.ExecuteNonQuery();

            }
        }

        public void Delete(int id)
        {
            IDbConnection conn = DBUtils.getConnection();
            using (var command = conn.CreateCommand())
            {
                command.CommandText = "DELETE FROM excursii WHERE id_excursie = @id";
                IDbDataParameter paramId = command.CreateParameter();
                paramId.ParameterName = "@id";
                paramId.Value = id;
                command.Parameters.Add(paramId);
                var dataR = command.ExecuteNonQuery();

            }
        }

        public void Update(Excursie e)
        {
            string obTuristic = e.ObTuristic;
            string firmaTransp = e.FirmaTransp;
            DateTime data = e.OraPlecare;
            long pret = e.Pret;
            int nrLocuri = e.NrLocuri;
            int id = e.Id;

            Excursie account = this.FindOne(id);
            IDbConnection conn = DBUtils.getConnection();

            using (var command = conn.CreateCommand())
            {
                command.CommandText = "update excursii  set ob_turistic = @ob_turistic, firma_transport=@firma, ora_plecare=@ora, pret=@pret, nr_locuri=@nr_locuri where id_excursie = @Id";
                //command.CommandText = "update excursii  set ob_turistic = 'Pisa',firma_transport='Alice',ora_plecare='3/30/2023 6:39 PM',pret=50,nr_locuri=27 where id_excursie = 3";
                var paramId = command.CreateParameter();
                paramId.ParameterName = "@ob_turistic";
                paramId.Value = obTuristic;
                command.Parameters.Add(paramId);

                var paramId1 = command.CreateParameter();
                paramId1.ParameterName = "@firma";
                paramId1.Value = firmaTransp;
                command.Parameters.Add(paramId1);

                var paramId2 = command.CreateParameter();
                paramId2.ParameterName = "@ora";
                paramId2.Value = data;
                command.Parameters.Add(paramId2);

                var paramId3 = command.CreateParameter();
                paramId3.ParameterName = "@pret";
                paramId3.Value = pret;
                command.Parameters.Add(paramId3);

                var paramId4 = command.CreateParameter();
                paramId4.ParameterName = "@nr_locuri";
                paramId4.Value = nrLocuri;
                command.Parameters.Add(paramId4);

                var paramId5 = command.CreateParameter();
                paramId5.ParameterName = "@Id";
                paramId5.Value = id;
                command.Parameters.Add(paramId5);

                var dataR = command.ExecuteNonQuery();
            }
        }

    }
}