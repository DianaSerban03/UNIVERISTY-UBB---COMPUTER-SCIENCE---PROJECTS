﻿
using model;
using persistence;

namespace persistence
{
    public interface IExcursie : IRepository<int, Excursie>
    {

    }
}