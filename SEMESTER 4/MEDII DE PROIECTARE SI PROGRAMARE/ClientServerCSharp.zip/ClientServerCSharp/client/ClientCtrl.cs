﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using model;
using services;

namespace client
{
    public class ClientCtrl : IObserver
    {
        public event EventHandler<UserEventArgs> updateEvent;
        private readonly IService server;
        private Angajat currentAngajat;

        public ClientCtrl(IService server)
        {
            this.server = server;
            currentAngajat = null;
        }

        public void login(String user, String password)
        {
            Angajat a = new Angajat(user, password);
            Angajat currentRef = server.Login(a, this);
            Console.WriteLine("LOGIN SUCCEDED ...");
            currentAngajat = currentRef;
            Console.WriteLine("Current User {0}", currentRef);

        }

        public void notifyAddedClient(Excursie e)
        {
            Console.WriteLine("Adding client to: " + e.ObTuristic);
            UserEventArgs userEventArgs = new UserEventArgs(UserEvent.NewClient, e);
            Console.WriteLine("Client added");
            OnUserEvent(userEventArgs);
        }

        protected virtual void OnUserEvent(UserEventArgs e)
        {
            if (updateEvent == null) return;
            updateEvent(this, e);
            Console.WriteLine("Update Event Called");
        }

        public void logout()
        {
            Console.WriteLine("Ctrl logout");
            server.Logout(currentAngajat.Id, this);
            currentAngajat = null;
        }

        public List<Excursie> getExcursii()
        {
            List<Excursie> e = server.GetAllExcursii();
            return e;
        }

        public List<Excursie> findByNameTime(string nume, int data1, int data2)
        {
            return server.FindByNameAndTime( nume,  data1,  data2);
        }

        public List<Angajat> getAngajati()
        {
            return server.GetAllAngajati();
        }

        public void addClient(Excursie e)
        {
           // Console.WriteLine(e.Referee.First_Name + "-->" + result.Participant.First_Name + " ==" + result.Points);
            UserEventArgs userEventArgs = new UserEventArgs(UserEvent.NewClient, e);
            OnUserEvent(userEventArgs);
            server.AddClient(e);
        }
    }
}