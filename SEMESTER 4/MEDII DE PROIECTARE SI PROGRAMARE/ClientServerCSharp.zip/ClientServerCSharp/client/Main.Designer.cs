﻿namespace INTERFATA_FORMS
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtOra1 = new TextBox();
            txtOra2 = new TextBox();
            txtNume = new TextBox();
            txtPrenume = new TextBox();
            txtTelefon = new TextBox();
            txtBilete = new TextBox();
            btnFILTER = new Button();
            btnADD = new Button();
            txtOb = new TextBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.Pink;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(8, 7);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(431, 233);
            dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 263);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(86, 15);
            label1.TabIndex = 1;
            label1.Text = "Nume excursie";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(33, 307);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(67, 15);
            label2.TabIndex = 2;
            label2.Text = "Ora pornire";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(33, 356);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(57, 15);
            label3.TabIndex = 3;
            label3.Text = "Ora ajuns";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(491, 52);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(40, 15);
            label4.TabIndex = 4;
            label4.Text = "Nume";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(491, 104);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(55, 15);
            label5.TabIndex = 5;
            label5.Text = "Prenume";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(491, 153);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(45, 15);
            label6.TabIndex = 6;
            label6.Text = "Telefon";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(491, 199);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(52, 15);
            label7.TabIndex = 7;
            label7.Text = "Nr bilete";
            // 
            // txtOra1
            // 
            txtOra1.BackColor = Color.Pink;
            txtOra1.Location = new Point(120, 307);
            txtOra1.Margin = new Padding(2);
            txtOra1.Name = "txtOra1";
            txtOra1.Size = new Size(106, 23);
            txtOra1.TabIndex = 8;
            // 
            // txtOra2
            // 
            txtOra2.BackColor = Color.Pink;
            txtOra2.Location = new Point(120, 355);
            txtOra2.Margin = new Padding(2);
            txtOra2.Name = "txtOra2";
            txtOra2.Size = new Size(106, 23);
            txtOra2.TabIndex = 9;
            // 
            // txtNume
            // 
            txtNume.BackColor = Color.Pink;
            txtNume.Location = new Point(594, 52);
            txtNume.Margin = new Padding(2);
            txtNume.Name = "txtNume";
            txtNume.Size = new Size(106, 23);
            txtNume.TabIndex = 10;
            // 
            // txtPrenume
            // 
            txtPrenume.BackColor = Color.Pink;
            txtPrenume.Location = new Point(594, 104);
            txtPrenume.Margin = new Padding(2);
            txtPrenume.Name = "txtPrenume";
            txtPrenume.Size = new Size(106, 23);
            txtPrenume.TabIndex = 11;
            // 
            // txtTelefon
            // 
            txtTelefon.BackColor = Color.Pink;
            txtTelefon.Location = new Point(594, 153);
            txtTelefon.Margin = new Padding(2);
            txtTelefon.Name = "txtTelefon";
            txtTelefon.Size = new Size(106, 23);
            txtTelefon.TabIndex = 12;
            // 
            // txtBilete
            // 
            txtBilete.BackColor = Color.Pink;
            txtBilete.Location = new Point(594, 199);
            txtBilete.Margin = new Padding(2);
            txtBilete.Name = "txtBilete";
            txtBilete.Size = new Size(106, 23);
            txtBilete.TabIndex = 13;
            // 
            // btnFILTER
            // 
            btnFILTER.BackColor = Color.Pink;
            btnFILTER.Location = new Point(285, 307);
            btnFILTER.Margin = new Padding(2);
            btnFILTER.Name = "btnFILTER";
            btnFILTER.Size = new Size(78, 20);
            btnFILTER.TabIndex = 14;
            btnFILTER.Text = "FILTER";
            btnFILTER.UseVisualStyleBackColor = false;
            btnFILTER.Click += btnFILTER_Click;
            // 
            // btnADD
            // 
            btnADD.BackColor = Color.Pink;
            btnADD.Location = new Point(545, 263);
            btnADD.Margin = new Padding(2);
            btnADD.Name = "btnADD";
            btnADD.Size = new Size(78, 20);
            btnADD.TabIndex = 15;
            btnADD.Text = "ADD";
            btnADD.UseVisualStyleBackColor = false;
            btnADD.Click += btnADD_Click;
            // 
            // txtOb
            // 
            txtOb.BackColor = Color.Pink;
            txtOb.Location = new Point(120, 260);
            txtOb.Name = "txtOb";
            txtOb.Size = new Size(106, 23);
            txtOb.TabIndex = 16;
            // 
            // button1
            // 
            button1.BackColor = Color.Pink;
            button1.Location = new Point(656, 359);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 17;
            button1.Text = "LOGOUT";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PaleVioletRed;
            ClientSize = new Size(753, 394);
            Controls.Add(button1);
            Controls.Add(txtOb);
            Controls.Add(btnADD);
            Controls.Add(btnFILTER);
            Controls.Add(txtBilete);
            Controls.Add(txtTelefon);
            Controls.Add(txtPrenume);
            Controls.Add(txtNume);
            Controls.Add(txtOra2);
            Controls.Add(txtOra1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Margin = new Padding(2);
            Name = "Main";
            Text = "Main";
            Load += Main_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtOra1;
        private TextBox txtOra2;
        private TextBox txtNume;
        private TextBox txtPrenume;
        private TextBox txtTelefon;
        private TextBox txtBilete;
        private Button btnFILTER;
        private Button btnADD;
        private TextBox txtOb;
        private Button button1;
    }
}