﻿using client;
using model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace INTERFATA_FORMS
{
    public partial class Main : Form
    {
        private readonly ClientCtrl ctrl;
        private readonly IEnumerable<Excursie> partData;
        public Main(ClientCtrl serviceComp)
        {
            InitializeComponent();
            ctrl = serviceComp;
            partData = ctrl.getExcursii();
            ctrl.updateEvent += excUpdate;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            //foreach (Excursie exc in serv.GetAllExcursii())
            //{
            //    dataGridView1.Rows.Add(exc.ObTuristic, exc.FirmaTransp, exc.OraPlecare, exc.Pret, exc.NrLocuri);
            //}
            dataGridView1.DataSource = ctrl.getExcursii();

            // dataGridView1.Rows[0].Selected = true;
        }



        private void btnFILTER_Click(object sender, EventArgs e)
        {
            // Get the selected item from the combo box
            string textObTuristic = txtOb.Text;

            // Get the values from the text boxes
            int textBox1Value = 0;
            int textBox2Value = 0;

            int.TryParse(txtOra1.Text, out textBox1Value);
            int.TryParse(txtOra2.Text, out textBox2Value);

            List<Excursie> excursies = ctrl.findByNameTime(textObTuristic, textBox1Value, textBox2Value);
            
            // Clear existing rows from the DataGridView
            //dataGridView1.Rows.Clear();

            // Add the new rows to the DataGridView
            //foreach (Excursie excursie in excursies)
            //{
            //    dataGridView1.Rows.Add(excursie.ObTuristic, excursie.FirmaTransp, excursie.OraPlecare, excursie.Pret, excursie.NrLocuri);
            //}
            dataGridView1.DataSource = excursies; // set the DataSource property to the updated data
            dataGridView1.Refresh();
            txtOb.Clear();
            txtOra1.Clear();
            txtOra2.Clear();

        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            string textNume = txtNume.Text;
            string textPrenume = txtPrenume.Text;
            string textTelefon = txtTelefon.Text;
            string textBilete = txtBilete.Text;

            int selectedId = 0;
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                selectedId = Convert.ToInt32(selectedRow.Cells["Id"].Value);
            }


            //List<Excursie> excursies = serv.AddClient(selectedId, textNume, textPrenume, textTelefon, textBilete);
            Excursie exc = new Excursie(selectedId.ToString(), "", DateTime.Now, 0, int.Parse(textBilete)); 
            ctrl.addClient(exc);
            dataGridView1.DataSource = ctrl.getExcursii(); // set the DataSource property to the updated data
            dataGridView1.Refresh();

            txtNume.Clear();
            txtPrenume.Clear();
            txtTelefon.Clear();
            txtBilete.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void excUpdate(object sender, UserEventArgs e)
        {
            if (e.UserEventType == UserEvent.NewClient)
            {
                Excursie exc = (Excursie)e.Data;

                foreach (Excursie ex in partData)
                    if (ex.Id == exc.Id)
                        ex.NrLocuri = exc.NrLocuri;


                List<Excursie> partDataList = partData.ToList();

                dataGridView1.DataSource = partDataList; // set the DataSource property to the updated data
                dataGridView1.Refresh();


            }
        }
    }
}
