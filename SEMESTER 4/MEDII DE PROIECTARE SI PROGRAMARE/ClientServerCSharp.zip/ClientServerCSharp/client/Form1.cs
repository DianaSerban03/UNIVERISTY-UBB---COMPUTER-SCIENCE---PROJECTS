using client;
using Microsoft.Win32;
using System;
using System.Windows.Forms;

namespace INTERFATA_FORMS
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        private ClientCtrl ctrl;
        public Form1(ClientCtrl serviceComp)
        {
            InitializeComponent();
            ctrl = serviceComp;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            try
            {
                Console.WriteLine("ZZZZZZZZZZZZZZZZZZZ  AICI ESTI IN Form1");
                ctrl.login(username, password);
                Main thrWin = new Main(ctrl);
                thrWin.Text = "Turism window for " + username;
                thrWin.Show();
                this.Hide();


            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Login error" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
        }
    }
}