﻿using System;
using System.Windows.Forms;
using INTERFATA_FORMS;
using networking;
using services;

namespace client
{
    static class StartClient
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            IService server = new ServerObjectProxy("127.0.0.2", 55559);
            ClientCtrl ctrl = new ClientCtrl(server);
            Form1 win = new Form1(ctrl);
            Application.Run(win);
        }
    }
}