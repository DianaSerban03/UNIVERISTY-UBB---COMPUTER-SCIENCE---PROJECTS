﻿using System;
using System.Net.Sockets;
using System.Threading;
using persistence;
using services;

namespace server
{
    using model;
    using networking;
    using server;
    using System.Diagnostics;
    using System.Xml.Schema;

    class StartServer
    {
        static void Main(string[] args)
        {
            AngajatRepoBD angRepo = new AngajatRepoBD();
            ClientRepoBD cliRepo = new ClientRepoBD();
            ExcursieRepoBD excRepo = new ExcursieRepoBD();
            IService serviceImpl = new ServiceImpl(angRepo, cliRepo, excRepo);


            SerialServer server = new SerialServer("127.0.0.2", 55559, serviceImpl);
            server.Start();
            foreach (Angajat a in serviceImpl.GetAllAngajati())
            {
                Console.WriteLine("username " + a.Username + " pass " + a.Password);
            }
            angRepo.Save(new Angajat("m1", "mmmmm"));
            Console.WriteLine("Server started ...");
            Console.ReadLine();



        }

        private string GetDebuggerDisplay()
        {
            return ToString();
        }
    }

    public class SerialServer : ConcurrentServer
    {
        private IService server;
        private ClientObjectWorker worker;
        public SerialServer(string host, int port, IService server) : base(host, port)
        {
            this.server = server;
            Console.WriteLine("SerialServer...");
            foreach (Angajat a in server.GetAllAngajati())
            {
                Console.WriteLine("username " + a.Username + " pass " + a.Password);
            }
        }
        protected override Thread createWorker(TcpClient client)
        {
            worker = new ClientObjectWorker(server, client);
            return new Thread(new ThreadStart(worker.run));
        }
    }
}