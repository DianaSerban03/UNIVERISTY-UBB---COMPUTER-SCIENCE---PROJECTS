﻿

using persistence;
using services;
using System;
using System.CodeDom.Compiler;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using model;

namespace server
{

    public class ServiceImpl : IService
    {
        private AngajatRepoBD angRepo;
        private ClientRepoBD cliRepo;
        private ExcursieRepoBD excRepo;
        private readonly ConcurrentDictionary<string, IObserver> loggedAngajati;

        public ServiceImpl(AngajatRepoBD A, ClientRepoBD C, ExcursieRepoBD E)
        {
            angRepo = A;
            cliRepo = C;
            excRepo = E;
            loggedAngajati = new ConcurrentDictionary<string, IObserver>();
        }

        public Angajat Login(Angajat a, IObserver client)
        {
            Angajat refOk = angRepo.FindOne(a.Username);
            if (refOk != null)
            {
                if (loggedAngajati.ContainsKey(refOk.Username))
                    throw new Exception("Angajat already logged in");
                loggedAngajati[refOk.Username] = client;
            }
            else
            {
                throw new Exception("Authentification failed");
            }

            return refOk;

        }
        private readonly int defaultThreadsNo = 4;
        
        //public void NotifyAddedClient(Excursie c)
        //{
        //    var executorService = Executors.NewFixedThreadPool(this.defaultThreadsNo);
        //    foreach (var pair in loggedAngajati)
        //    {
        //        var id = pair.Key;
        //        var client = pair.Value;
        //        executorService.Execute(() =>
        //        {
        //            try
        //            {
        //                Console.WriteLine($"Notifying [{id}]");
        //                client.NotifyAddedClient(c);
        //            }
        //            catch (Exception e)
        //            {
        //                Console.WriteLine($"Error notifying ang with ID: {id}. Message: {e.Message}");
        //            }
        //        });
        //    }
        //    executorService.Shutdown();
        //}
        
        public void AddClient(Excursie e)
        {
            Console.Error.WriteLine("AM AJUNS in ServiceImpl addClient");

            int obTuristicInt = int.Parse(e.ObTuristic);
            Excursie oldExc = excRepo.FindOne(obTuristicInt);
            int scade_locuri = oldExc.NrLocuri - e.NrLocuri;
            oldExc.Id = obTuristicInt;

            Excursie newE = new Excursie(oldExc.ObTuristic, oldExc.FirmaTransp, oldExc.OraPlecare, oldExc.Pret, scade_locuri);
            newE.Id = obTuristicInt;
            excRepo.Update(newE);
            Console.WriteLine("duuuuuuuuuuuupa updaaaaaaaaaate" + excRepo.FindOne(newE.Id).NrLocuri);
            //NotifyAddedClient(newE);

            foreach (String a in loggedAngajati.Keys)
            {
                Console.WriteLine("Angajatul with ID " + a + " a primit notificare de scor nou");
                IObserver refClient = loggedAngajati[a];
                Task.Run(() => refClient.notifyAddedClient(newE));
            }
        }

        public void Logout(string id, IObserver client)
        {
            if (!loggedAngajati.TryRemove(id, out IObserver localClient))
                throw new Exception($"Angajat {id} is not logged in.");
        }

        public List<Excursie> FindByNameAndTime(string nume, int data1, int data2)
        {
            Console.WriteLine("esti in ServiceImpl la findBy");
            List<Excursie> excursieList = new List<Excursie>();
            foreach (Excursie e in excRepo.FindAll())
            {
                Console.WriteLine("excursriile suuuuuuuuuunt" + " " + e.ObTuristic + " " + nume);
                Console.WriteLine(e.OraPlecare.Hour + " si data1 selectat= " + data1);
                if (e.ObTuristic == nume)
                {
                    excursieList.Add(e);
                }
            }
            return excursieList;
        }

        public List<Angajat> GetAllAngajati()
        {
            return (List<Angajat>)angRepo.FindAll();
        }

        public List<Client> GetAllClienti()
        {
            return (List<Client>)cliRepo.FindAll();
        }

        public List<Excursie> GetAllExcursii()
        {
            return (List<Excursie>)excRepo.FindAll();
        }

    }
}