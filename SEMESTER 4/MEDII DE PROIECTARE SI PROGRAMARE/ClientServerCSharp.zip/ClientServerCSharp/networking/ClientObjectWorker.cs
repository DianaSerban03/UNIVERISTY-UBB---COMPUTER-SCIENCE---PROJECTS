﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using model;
using services;

namespace networking
{
    public class ClientObjectWorker : IObserver
    {
        private IService server;
        private TcpClient connection;

        private NetworkStream stream;
        private IFormatter formatter;
        private volatile bool connected;

        public ClientObjectWorker(IService server, TcpClient connection)
        {
            this.server = server;
            this.connection = connection;
            try
            {
                stream = this.connection.GetStream();
                formatter = new BinaryFormatter();
                connected = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        public virtual void run()
        {
            while (connected)
            {
                try
                {
                    object request = formatter.Deserialize(stream);
                    object response = handleRequest((Request)request);
                    if (response != null)
                    {
                        sendResponse((Response)response);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }

                try
                {
                    Thread.Sleep(1000);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.StackTrace);
                }
            }

            try
            {
                stream.Close();
                connection.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error " + e);
            }
        }

        public void notifyAddedClient(Excursie e)
        {
            Console.WriteLine("Client added -> " + e);
            try
            {
                sendResponse(new NewClientResponse(e));
            }
            catch (Exception ex)
            {
                throw new Exception("Adding error");
            }
        }

        private Response handleRequest(Request request)
        {
            Response response = null;
            if (request is LoginRequest)
            {
                Console.WriteLine("LOGIN REQUEST");
                LoginRequest logReq = (LoginRequest)request;
                Angajat a = logReq.Angajat;
                try
                {
                    Angajat findAngajat;
                    lock (server)
                    {
                        findAngajat = server.Login(a, this);
                        Console.WriteLine("ANGAJAT GASIT " + findAngajat.Id + findAngajat.Username);
                    }

                    return new LoginResponse(findAngajat);
                    //return new OkResponse();
                }
                catch (Exception e)
                {
                    connected = false;
                    return new ErrorResponse(e.Message);
                }
            }

            if (request is LogoutRequest)
            {
                Console.WriteLine("LOGOUT");
                LogoutRequest logReq = (LogoutRequest)request;
                string a = logReq.Angajat;
                try
                {
                    lock (server)
                    {
                        server.Logout(a, this);
                    }

                    connected = false;
                    return new OkResponse();
                }
                catch (Exception e)
                {
                    return new ErrorResponse(e.Message);
                }
            }

            if (request is AddClientRequest)
            {
                Console.WriteLine("Adding Client");
                AddClientRequest addReq = (AddClientRequest)request;
                Excursie e = addReq.Excursie;
                try
                {
                    lock (server)
                    {
                        server.AddClient(e);
                    }

                    return new OkResponse();
                }
                catch (Exception ex)
                {
                    return new ErrorResponse(ex.Message);
                }
            }

            if (request is FindByNameTimeRequest)
            {
                Console.WriteLine("esti in ObjectWorker la findBy");
                FindByNameTimeRequest addReq = (FindByNameTimeRequest)request;
                Excursie e = addReq.Excursie;
                try
                {
                    List<Excursie> exc;
                    lock (server)
                    {
                        DateTime dateTime = e.OraPlecare;
                        int hour = dateTime.Hour;
                        exc=server.FindByNameAndTime(e.ObTuristic, hour, 12);
                    }

                    return new FindByNameTimeResponse(exc);
                }
                catch (Exception ex)
                {
                    return new ErrorResponse(ex.Message);
                }
            }

            if (request is GetAngajatiRequest)
            {
                Console.WriteLine("Get Angajati");
                GetAngajatiRequest addReq = (GetAngajatiRequest)request;
                try
                {
                    List<Angajat> a;
                    lock (server)
                    {
                       a=server.GetAllAngajati();
                    }

                    return new GetAngajatiResponse(a);
                }
                catch (Exception ex)
                {
                    return new ErrorResponse(ex.Message);
                }
            }
            if (request is GetExcursieRequest)
            {
                Console.WriteLine("Get Excursii");
                GetExcursieRequest addReq = (GetExcursieRequest)request;
                try
                {
                    List<Excursie> excursii;
                    lock (server)
                    {
                        excursii=server.GetAllExcursii();
                    }

                    return new GetExcursieResponse(excursii);
                }
                catch (Exception ex)
                {
                    return new ErrorResponse(ex.Message);
                }
            }
            return response;

        }

        private void sendResponse(Response response)
        {

            try
            {
                Console.WriteLine("Sending response..." + response);
                lock (stream)
                {
                    Console.WriteLine("BEFOOOOOOOOOORE");
                    formatter.Serialize(stream, response);
                    Console.WriteLine("AFTTTTTTTTTER");
                    stream.Flush();
                    Console.WriteLine("AFTEEEEEEEEEEER 2");
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error sending object " + response);
            }
        }


    }
}