﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using model;
using services;

namespace networking
{
    public class ServerObjectProxy : IService
    {
        private string host;
        private int port;

        private IObserver client;

        private NetworkStream stream;

        private IFormatter formatter;
        private TcpClient connection;

        private Queue<Response> responses;
        private volatile bool finished;
        private EventWaitHandle waitHandle;

        public ServerObjectProxy(string host, int port)
        {
            this.host = host;
            this.port = port;
            responses = new Queue<Response>();
        }



        public virtual Angajat Login(Angajat angajat, IObserver client)
        {
            Debug.WriteLine("ZZZZZZZZZZZZZZZZZZZ  AICI ESTI IN ServerObjectProxy");
            initializeConnection();
            Debug.WriteLine("SE TRIMITE CERERE DE LOGIN si avem angajaul cu username "+angajat.Username);
            sendRequest(new LoginRequest(angajat));
            Debug.WriteLine("SE CITESTE RASPUNSUL DE LA SV");
            Response response = readResponse();
            Debug.WriteLine("VERIFICAM RASPUNSUL");
            if (response is LoginResponse)
            {
                this.client = client;
                LoginResponse resp = (LoginResponse)response;
                Angajat returnedAngajat = resp.Angajat;
                Debug.WriteLine("LOGIN RETURNED " + returnedAngajat.Username + " " + returnedAngajat.Id);
                return returnedAngajat;
            }

            if (response is ErrorResponse)
            {
                Debug.WriteLine("proooooooooooooooooooooooooxy ANGAJAT = " + angajat.Username + "pass "+angajat.Password);
                ErrorResponse err = (ErrorResponse)response;
                closeConnection();
                throw new Exception(err.Message);
            }

            return angajat;
        }


        public void AddClient(Excursie result)
        {
            sendRequest(new AddClientRequest(result));
            Response response = readResponse();
            if (response is ErrorResponse)
            {
                ErrorResponse err = (ErrorResponse)response;
                throw new Exception(err.Message);
            }
        }
        public List<Excursie> FindByNameAndTime(string nume, int data1, int data2)
        {
            Console.WriteLine("esti in Porxy la findBy");
            int hour = data1;
            DateTime dateTime = new DateTime(1, 1, 1, hour, 0, 0);

            Excursie e = new Excursie(nume, " ", dateTime, 0, 0);
            sendRequest(new FindByNameTimeRequest(e));
            Response response = readResponse();
            if (response is ErrorResponse)
            {
                ErrorResponse err = (ErrorResponse)response;
                throw new Exception(err.Message);
            }

            FindByNameTimeResponse resp = (FindByNameTimeResponse)response;
            List<Excursie> excursii = resp.Excursie;
            return excursii;

        }
        public List<Angajat> GetAllAngajati()
        {
            sendRequest(new GetAngajatiRequest());
            Response response = readResponse();
            if (response is ErrorResponse)
            {
                ErrorResponse err = (ErrorResponse)response;
                throw new Exception(err.Message);
            }
            GetAngajatiResponse resp = (GetAngajatiResponse)response;
            List<Angajat> excursii = resp.Angajat;
            return excursii;
        }
        public List<Excursie> GetAllExcursii()
        {
            sendRequest(new GetExcursieRequest());
            Response response = readResponse();
            if (response is ErrorResponse)
            {
                ErrorResponse err = (ErrorResponse)response;
                throw new Exception(err.Message);
            }
            GetExcursieResponse resp = (GetExcursieResponse)response;
            List<Excursie> excursii = resp.Excursie;
            return excursii;
        }

        public void Logout(string id, IObserver client)
        {
            sendRequest(new LogoutRequest(id));
            Response response = readResponse();
            closeConnection();
            if (response is ErrorResponse)
            {
                ErrorResponse err = (ErrorResponse)response;
                throw new Exception(err.Message);
            }
        }



        private void initializeConnection()
        {
            try
            {
                connection = new TcpClient(host, port);
                stream = connection.GetStream();
                formatter = new BinaryFormatter();
                finished = false;
                waitHandle = new AutoResetEvent(false);
                startReader();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        private void startReader()
        {
            Thread tw = new Thread(run);
            tw.Start();
        }

        private void sendRequest(Request request)
        {
            try
            {
                Debug.WriteLine("ZZZZZZZZZZZZZZZZZZZ  AICI ESTI IN sendRequest din Proxy BEFORE ");
                formatter.Serialize(stream, request);
                Debug.WriteLine("ZZZZZZZZZZZZZZZZZZZ  AICI ESTI IN sendRequest din Proxy AFTER");
                stream.Flush();

            }
            catch (Exception e)
            {
                throw new Exception("Error sending object " + request);
            }
        }



        private Response readResponse()
        {
            Response response = null;
            try
            {
                waitHandle.WaitOne();
                lock (responses)
                {
                    response = responses.Dequeue();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

            return response;
        }

        private void handleUpdate(UpdateResponse update)
        {
            if (update is NewClientResponse)
            {
                NewClientResponse excUpd = (NewClientResponse)update;
                Excursie e = excUpd.Excursie;
                Console.WriteLine("Score added to " + e);
                try
                {
                    client.notifyAddedClient(e);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.StackTrace);
                }
            }
        }

        private void closeConnection()
        {
            finished = true;
            try
            {
                stream.Close();

                connection.Close();
                waitHandle.Close();
                client = null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        public virtual void run()
        {
            while (!finished)
            {
                try
                {
                    object response = formatter.Deserialize(stream);
                    Console.WriteLine("Response received " + response);
                    if (response is UpdateResponse)
                    {
                        handleUpdate((UpdateResponse)response);
                    }
                    else
                    {
                        lock (responses)
                        {
                            responses.Enqueue((Response)response);
                        }

                        waitHandle.Set();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Reading error " + e);
                }
            }
        }
    }
}