﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using model;

namespace networking
{
    public interface Request
    {
    }

    [Serializable]
    public class LoginRequest : Request
    {
        private Angajat angajat;
        public LoginRequest(Angajat angajat)
        {
            this.angajat = angajat;
        }
        public virtual Angajat Angajat
        {
            get { return angajat; }
        }
    }


    [Serializable]
    public class LogoutRequest : Request
    {
        private string angajat;
        public LogoutRequest(string angajat)
        {
            this.angajat = angajat;
        }
        public virtual string Angajat
        {
            get { return angajat; }
        }
    }

    [Serializable]
    public class AddClientRequest : Request
    {
        private Excursie excursie;
        public AddClientRequest(Excursie excursie)
        {
            this.excursie = excursie;
        }

        public virtual Excursie Excursie
        {
            get { return excursie; }
        }
    }

    [Serializable]
    public class FindByNameTimeRequest : Request
    {
        private Excursie excursie;
        public FindByNameTimeRequest(Excursie excursie)
        {
            this.excursie = excursie;
        }

        public virtual Excursie Excursie
        {
            get { return excursie; }
        }
    }

    [Serializable]
    public class GetAngajatiRequest : Request
    {
        private List<Angajat> angajati;
        public GetAngajatiRequest()
        {
            this.angajati = new List<Angajat>();
        }

        public virtual List<Angajat> Angajat
        {
            get { return angajati; }
        }
    }

    [Serializable]
    public class GetExcursieRequest : Request
    {
        private List<Excursie> excursii;
        public GetExcursieRequest()
        {
            this.excursii = new List<Excursie>();
        }

        public virtual List<Excursie> Excursii
        {
            get { return excursii; }
        }
    }




}