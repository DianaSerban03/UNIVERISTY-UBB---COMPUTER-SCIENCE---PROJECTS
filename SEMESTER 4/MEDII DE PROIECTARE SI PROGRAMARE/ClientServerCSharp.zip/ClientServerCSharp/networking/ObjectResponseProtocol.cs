﻿using System;
using System.Collections.Generic;
using model;

namespace networking
{
    public interface Response { }

    [Serializable]
    public class OkResponse : Response { }

    [Serializable]
    public class ErrorResponse : Response
    {
        private string message;

        public ErrorResponse(string message)
        {
            this.message = message;
        }

        public virtual string Message
        {
            get
            {
                return message;
            }
        }
    }

  

    [Serializable]
    public class LoginResponse : Response
    {
        private Angajat angajat;

        public LoginResponse(Angajat angajat)
        {
            this.angajat = angajat;
        }

        public virtual Angajat Angajat
        {
            get { return angajat; }
        }
    }

    public interface UpdateResponse : Response { }

    [Serializable]
    public class NewClientResponse : UpdateResponse
    {
        private Excursie excursie;

        public NewClientResponse(Excursie excursie)
        {
            this.excursie = excursie;
        }
        public virtual Excursie Excursie
        {
            get
            {
                return excursie;
            }
        }
    }

    [Serializable]
    public class FindByNameTimeResponse : Response
    {
        private List<Excursie> excursie;
        public FindByNameTimeResponse(List<Excursie> excursie)
        {
            this.excursie = excursie;
        }

        public virtual List<Excursie> Excursie
        {
            get { return excursie; }
        }
    }

    [Serializable]
    public class GetAngajatiResponse : Response
    {
        private List<Angajat> angajati;
        public GetAngajatiResponse(List<Angajat> angajati)
        {
            this.angajati = angajati;
        }

        public virtual List<Angajat> Angajat
        {
            get { return angajati; }
        }
    }

    [Serializable]
    public class GetExcursieResponse : Response
    {
        private List<Excursie> e;
        public GetExcursieResponse(List<Excursie> e)
        {
            this.e = e;
        }

        public virtual List<Excursie> Excursie
        {
            get { return e; }
        }
    }
}