﻿using System;
namespace model
{
    [Serializable]
    public class Angajat : Entity<string>
    {
        public string Id { get; set; }
        private string username;
        private string password;

        public Angajat(string username, string password)
        {
            this.username = username;
            this.password = password;
        }

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
    }
}