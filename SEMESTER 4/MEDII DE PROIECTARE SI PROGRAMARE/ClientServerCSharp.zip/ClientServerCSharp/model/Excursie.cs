﻿using System;

namespace model
{
    [Serializable]
    public class Excursie : Entity<int>
    {
        public int Id { get; set; }
        private string obTuristic;
        private string firmaTransp;
        private DateTime oraPlecare;
        private long pret;
        private int nrLocuri;

        public Excursie(string obTuristic, string firmaTransp, DateTime oraPlecare, long pret, int nrLocuri)
        {
            this.obTuristic = obTuristic;
            this.firmaTransp = firmaTransp;
            this.oraPlecare = oraPlecare;
            this.pret = pret;
            this.nrLocuri = nrLocuri;
        }

        public string ObTuristic
        {
            get { return obTuristic; }
            set { obTuristic = value; }
        }

        public string FirmaTransp
        {
            get { return firmaTransp; }
            set { firmaTransp = value; }
        }

        public DateTime OraPlecare
        {
            get { return oraPlecare; }
            set { oraPlecare = value; }
        }

        public long Pret
        {
            get { return pret; }
            set { pret = value; }
        }

        public int NrLocuri
        {
            get { return nrLocuri; }
            set { nrLocuri = value; }
        }
    }
}