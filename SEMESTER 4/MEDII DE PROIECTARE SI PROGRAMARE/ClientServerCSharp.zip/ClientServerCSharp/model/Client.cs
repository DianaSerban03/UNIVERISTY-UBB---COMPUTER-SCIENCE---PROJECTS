﻿

namespace model
{
    [Serializable]
    public class Client : Entity<int>
    {
        public int Id { get; set; }
        private string nume;
        private string prenume;
        private long telefon;
        private long nrBilete;

        public Client(string nume, string prenume, long telefon, long nrBilete)
        {
            this.nume = nume;
            this.prenume = prenume;
            this.telefon = telefon;
            this.nrBilete = nrBilete;
        }

        public string Prenume
        {
            get { return prenume; }
            set { prenume = value; }
        }
        
        public string Nume
        {
            get { return nume; }
            set { nume = value; }
        }

        public long Telefon
        {
            get { return telefon; }
            set { telefon = value; }
        }

        public long NrBilete
        {
            get { return nrBilete; }
            set { nrBilete = value; }
        }
    }
}